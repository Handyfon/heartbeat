<b>SUPPORT: https://discord.gg/gs5hAgxBx3</b></br>
Make hp changes exiting and immersive!

Adds a video game like overlay when your character gets hurt and makes taking damage more dramatic and fun for your players!
You can preview the module as a GM without logging in as a player :D

Features:<br>
- Damage overlay, red overlay that gets more visible as health goes down.<br>
- Damage feedback, red or green flash that disappears quickly when you lose or restore health<br>
- Heartbeat animation and sound when players reach a certain health percentage<br>
- Massive damage sound that will be played when players lose 50% health in one instance.<br>

This module is system agnostic and very customizable!

Customize at whish percentages the effects start<br>
- Custom Sounds<br>
- Custom Overlay<br>
- Configure how strong the effects are<br>
- Disable any effects you dislike<br>
- This module is not available in the module browser until the end of the month.
<br>

<h1>Images and Gifs:</h1>
<div>
Demonstration:
https://imgur.com/CmFBFsw.gif
Low HP:<br>
https://imgur.com/5UNkbSl.gif
Player_Death<br>
https://imgur.com/erUkfZP.gif

